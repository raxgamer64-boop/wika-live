# Wika Live

Cross-platform Flutter foundation for Wika Live.

## Current build
- Android + iOS capable Flutter project
- Wika Live branding
- Home / Live / Party / Messages / Profile navigation
- Wallet and notification entry points

## Next modules
1. Authentication
2. Backend + database
3. Live video/audio rooms
4. Real-time chat
5. Coins and gifts
6. Host earnings
7. Agency system
8. Coin seller system
9. Withdrawals
10. Admin dashboard
