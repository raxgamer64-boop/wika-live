import 'package:flutter/material.dart';

void main() => runApp(const WikaLiveApp());

class WikaLiveApp extends StatelessWidget {
  const WikaLiveApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Wika Live',
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF0B0B12),
      ),
      home: const WikaHome(),
    );
  }
}

class WikaHome extends StatefulWidget {
  const WikaHome({super.key});

  @override
  State<WikaHome> createState() => _WikaHomeState();
}

class _WikaHomeState extends State<WikaHome> {
  int index = 0;

  final pages = const [
    Center(child: Text('Home', style: TextStyle(fontSize: 28))),
    Center(child: Text('Live', style: TextStyle(fontSize: 28))),
    Center(child: Text('Party', style: TextStyle(fontSize: 28))),
    Center(child: Text('Messages', style: TextStyle(fontSize: 28))),
    Center(child: Text('Profile', style: TextStyle(fontSize: 28))),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Wika Live',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.notifications_none_rounded),
          ),
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.account_balance_wallet_outlined),
          ),
        ],
      ),
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.live_tv_outlined), label: 'Live'),
          NavigationDestination(icon: Icon(Icons.groups_outlined), label: 'Party'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'Messages'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }
}
